# ViolaJonesCascades
xml files for OpenCV designed for different face related.

Detectors include as target head and shoulders, eye, ears, mouth and nose detection. Most of them were distributed whithin OpenCV before release 3

A couple of python sample codes are included. 

Observe the license details included in each xml file.
